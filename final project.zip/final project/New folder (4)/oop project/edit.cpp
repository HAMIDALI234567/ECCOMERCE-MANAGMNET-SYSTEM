#include "edit.h"
#include "ui_edit.h"
#include <QMessageBox>
#include <QFile>
#include <QTextStream>

edit::edit(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::edit)
{
    ui->setupUi(this);

    // Set up placeholders for input fields
    ui->lineEdit_code->setPlaceholderText("Enter Unique Code");
    ui->lineEdit_newName->setPlaceholderText("Enter New Name");
    ui->lineEdit_newPrice->setPlaceholderText("Enter New Price");
    ui->lineEdit_newItems->setPlaceholderText("Enter New Number of Items");
}

edit::~edit()
{
    delete ui;
}

void edit::on_pushButton_clicked()
{
    QString code = ui->lineEdit_code->text();
    QString newName = ui->lineEdit_newName->text();
    QString newPrice = ui->lineEdit_newPrice->text();
    QString newItems = ui->lineEdit_newItems->text();

    if (code.isEmpty() || (newName.isEmpty() && newPrice.isEmpty() && newItems.isEmpty())) {
        QMessageBox::warning(this, "Input Error", "Code is required and at least one field (Name, Price, or Items) must be filled!");
        return;
    }

    QFile file("products.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "File Error", "Unable to open file for reading.");
        return;
    }

    QString updatedContent;
    QTextStream in(&file);
    bool codeFound = false;

    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList parts = line.split(",");
        if (parts.size() >= 4 && parts[2].trimmed() == code) {
            if (!newName.isEmpty()) parts[0] = newName;
            if (!newPrice.isEmpty()) parts[1] = newPrice;
            if (!newItems.isEmpty()) parts[3] = newItems;
            codeFound = true;
        }
        updatedContent += parts.join(",") + "\n";
    }

    file.close();

    if (!codeFound) {
        QMessageBox::warning(this, "Not Found", "The entered code does not exist!");
        return;
    }

    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "File Error", "Unable to open file for writing.");
        return;
    }

    QTextStream out(&file);
    out << updatedContent;
    file.close();

    QMessageBox::information(this, "Success", "The product has been updated successfully.");
    ui->lineEdit_code->clear();
    ui->lineEdit_newName->clear();
    ui->lineEdit_newPrice->clear();
    ui->lineEdit_newItems->clear();
}
