#include "options.h"
#include "ui_options.h"

options::options(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::options)
{
    ui->setupUi(this);
}

options::~options()
{
    delete ui;
}

void options::on_pushButton_clicked()
{


}


void options::on_pushButton_4_clicked()
{
    this->close();
}

