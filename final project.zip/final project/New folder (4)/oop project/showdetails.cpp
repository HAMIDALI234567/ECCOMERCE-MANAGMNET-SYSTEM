#include "showdetails.h"
#include "ui_showdetails.h"
#include <QFile>
#include <QTextStream>
#include <QStandardItemModel>
#include <QMessageBox>
#include <QInputDialog>
#include <QPushButton>

showdetails::showdetails(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::showdetails)
    , model(new QStandardItemModel(this)) // Initialize the model
{
    ui->setupUi(this);

    // Set column headers
    model->setHorizontalHeaderLabels({ "Name", "Price", "Unique Code", "No. of Items" });

    // Open products.txt for reading
    QFile file("products.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "File Error", "Unable to open products.txt for reading.");
        return;
    }

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList parts = line.split(",");

        // Validate the data structure
        if (parts.size() == 4) {
            QList<QStandardItem *> row;
            row.append(new QStandardItem(parts[0].trimmed())); // Name
            row.append(new QStandardItem(parts[1].trimmed())); // Price
            row.append(new QStandardItem(parts[2].trimmed())); // Unique Code
            row.append(new QStandardItem(parts[3].trimmed())); // No. of Items

            model->appendRow(row);
        } else {
            QMessageBox::warning(this, "Data Error", "Malformed product entry skipped: " + line);
        }
    }

    file.close();

    // Set the model to the table view
    ui->tableView->setModel(model);
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableView->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tableView->horizontalHeader()->setStretchLastSection(true);
    ui->tableView->resizeColumnsToContents();

    // Connect the billing button
    connect(ui->btnBill, &QPushButton::clicked, this, &showdetails::processBilling);
}

showdetails::~showdetails()
{
    delete ui;
}

void showdetails::processBilling()
{
    double totalBill = 0.0;
    QList<QString> billedItems; // Track billed items for better feedback

    while (true) {
        // Ask user for unique code
        bool ok;
        QString uniqueCode = QInputDialog::getText(this, "Enter Unique Code",
                                                   "Enter the unique code of the product:",
                                                   QLineEdit::Normal, QString(), &ok);

        if (!ok || uniqueCode.isEmpty()) {
            break; // Exit if the user cancels
        }

        // Find the product in the model
        bool productFound = false;
        for (int row = 0; row < model->rowCount(); ++row) {
            QString code = model->item(row, 2)->text(); // Unique Code column
            if (code == uniqueCode) {
                productFound = true;

                // Get the product details
                QString name = model->item(row, 0)->text();
                double price = model->item(row, 1)->text().toDouble();
                int stock = model->item(row, 3)->text().toInt();

                if (stock == 0) {
                    QMessageBox::warning(this, "Out of Stock", QString("%1 is out of stock.").arg(name));
                    break;
                }

                // Ask for the number of items
                int quantity = QInputDialog::getInt(this, "Enter Quantity",
                                                    QString("Enter the quantity for %1 (Available: %2):").arg(name).arg(stock),
                                                    1, 1, stock, 1, &ok);

                if (!ok) {
                    break; // Exit if the user cancels
                }

                // Update stock in the model
                stock -= quantity;
                model->item(row, 3)->setText(QString::number(stock));

                // Calculate the total for this product
                double itemTotal = price * quantity;
                totalBill += itemTotal;
                billedItems.append(QString("%1 x %2 = %3").arg(quantity).arg(name).arg(itemTotal));

                QMessageBox::information(this, "Item Added",
                                         QString("Added %1 x %2 to the bill. Subtotal: %3")
                                             .arg(quantity).arg(name).arg(itemTotal));
                break;
            }
        }

        if (!productFound) {
            QMessageBox::warning(this, "Product Not Found", "The entered unique code does not match any product.");
        }
    }

    // Display the final bill
    if (!billedItems.isEmpty()) {
        QString billDetails = billedItems.join("\n");
        billDetails.append(QString("\n\nTotal Bill: %1").arg(totalBill));

        QMessageBox::information(this, "Total Bill", billDetails);
    } else {
        QMessageBox::information(this, "Billing Cancelled", "No items were billed.");
    }
}
