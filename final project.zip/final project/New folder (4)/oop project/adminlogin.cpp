#include "adminlogin.h"
#include "ui_adminlogin.h"
#include <QMessageBox>
#include "adminpanel.h"

adminlogin::adminlogin(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::adminlogin)
{
    ui->setupUi(this);
    this->setStyleSheet(
            "QDialog {"
            "    background-image: url(:/img/image/hamidddddddddddd.jpg);"
            "    background-repeat: no-repeat;"
            "    background-position: center;"
            "    background-size: 10% 10%;"
            "}"
    );
        // Set up placeholders for input fields
    ui->lineEdit_username->setPlaceholderText("Enter Username");
    ui->lineEdit_password->setPlaceholderText("Enter Password");
    ui->lineEdit_password->setEchoMode(QLineEdit::Password); // Mask password input
}

adminlogin::~adminlogin()
{
    delete ui;
}

void adminlogin::on_pushButton_clicked()
{
    QString username = ui->lineEdit_username->text();
    QString password = ui->lineEdit_password->text();

    // Predefined admin credentials
    QString admin1Name = "mubeen";
    QString admin1Pass = "gohar";

    QString admin2Name = "hamid";
    QString admin2Pass = "ali";

    // Check credentials
    if ((username == admin1Name && password == admin1Pass) ||
        (username == admin2Name && password == admin2Pass)) {
        QMessageBox::information(this, "Login Success", "Welcome, Admin!");

       // accept(); // Close the login dialog and proceed

        // Open Admin Panel
        AdminPanel *w = new AdminPanel(this); // Create a new AdminPanel instance
        w->setAttribute(Qt::WA_DeleteOnClose); // Ensure it gets deleted on close
        w->show();

    } else {
        QMessageBox::warning(this, "Login Failed", "Invalid username or password. Please try again.");
    }
}



void adminlogin::on_label_3_linkActivated(const QString &link)
{

}

