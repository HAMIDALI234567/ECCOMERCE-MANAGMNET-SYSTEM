#include "add.h"
#include "ui_add.h"
#include <QMessageBox>
#include <QFile>
#include <QTextStream>

add::add(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::add)
{
    ui->setupUi(this);

    // Set up placeholders for input fields
    ui->lineEdit_name->setPlaceholderText("Enter Name");
    ui->lineEdit_price->setPlaceholderText("Enter Price");
    ui->lineEdit_code->setPlaceholderText("Enter Unique Code");
    ui->lineEdit_noofitems->setPlaceholderText("Enter Number of Items");
}

add::~add()
{
    delete ui;
}

void add::on_pushButton_clicked()
{
    // Get inputs from user
    QString name = ui->lineEdit_name->text();
    QString price = ui->lineEdit_price->text();
    QString code = ui->lineEdit_code->text();
    QString noofitems = ui->lineEdit_noofitems->text();

    // Validate inputs
    if (name.isEmpty() || price.isEmpty() || code.isEmpty() || noofitems.isEmpty()) {
        QMessageBox::warning(this, "Input Error", "All fields are required!");
        return;
    }

    // Validate unique code
    bool isNumber;
    int codeNumber = code.toInt(&isNumber);
    if (!isNumber) {
        QMessageBox::warning(this, "Input Error", "Unique Code must be a number!");
        return;
    }

    // Validate number of items
    int itemsNumber = noofitems.toInt(&isNumber);
    if (!isNumber || itemsNumber <= 0) {
        QMessageBox::warning(this, "Input Error", "Number of Items must be a positive number!");
        return;
    }

    // Save data to file
    QFile file("products.txt");
    if (!file.open(QIODevice::Append | QIODevice::Text)) {
        QMessageBox::critical(this, "File Error", "Unable to open file for writing.");
        return;
    }

    QTextStream out(&file);
    out << name << "," << price << "," << code << "," << noofitems << "\n";
    file.close();

    // Provide confirmation
    QMessageBox::information(this, "Success", QString("Item Added:\nName: %1\nPrice: %2\nUnique Code: %3\nNumber of Items: %4")
                                                  .arg(name).arg(price).arg(code).arg(noofitems));

    // Clear input fields
    ui->lineEdit_name->clear();
    ui->lineEdit_price->clear();
    ui->lineEdit_code->clear();
    ui->lineEdit_noofitems->clear();
}
