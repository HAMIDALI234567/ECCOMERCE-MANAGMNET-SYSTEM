#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<login.h>
#include <QFile>
#include <QDataStream>
#include <QMessageBox>
#include<adminpanel.h>
#include<adminlogin.h>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    QString username = ui->lineEdit_username->text();
    QString password = ui->lineEdit_password->text();

    if (username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "Error", "Username or Password cannot be empty!");
        return;
    }

    QFile file("credential.dat");
    if (!file.open(QIODevice::Append)) {
        QMessageBox::critical(this, "Error", "Failed to open file for writing.");
        return;
    }

    QDataStream out(&file);
    out << username << password;

    file.close();

    QMessageBox::information(this, "Success", "Credentials stored successfully!");

    ui->lineEdit_username->clear();
    ui->lineEdit_password->clear();
}


void MainWindow::on_pushButton_2_clicked()
{
    login *w = new login(this); // Create a new login dialog instance
    w->setAttribute(Qt::WA_DeleteOnClose); // Ensure it gets deleted on close
    w->show(); // Show the login dialog

}


void MainWindow::on_pushButton_3_clicked()
{
    adminlogin *w = new adminlogin(this); // Create a new login dialog instance
    w->setAttribute(Qt::WA_DeleteOnClose); // Ensure it gets deleted on close
    w->show();
}

