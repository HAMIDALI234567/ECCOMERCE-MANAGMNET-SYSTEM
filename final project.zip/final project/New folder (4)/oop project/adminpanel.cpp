#include "adminpanel.h"
#include "ui_adminpanel.h"
#include<add.h>
#include<edit.h>
#include<delet.h>
AdminPanel::AdminPanel(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AdminPanel)
{
    ui->setupUi(this);
}

AdminPanel::~AdminPanel()
{
    delete ui;
}

void AdminPanel::on_pushButton_clicked()
{
    add *w = new add(this); // Create a new login dialog instance
    w->setAttribute(Qt::WA_DeleteOnClose); // Ensure it gets deleted on close
    w->show();
}


void AdminPanel::on_pushButton_2_clicked()
{
    edit *w = new edit(this); // Create a new login dialog instance
    w->setAttribute(Qt::WA_DeleteOnClose); // Ensure it gets deleted on close
    w->show();
}


void AdminPanel::on_pushButton_3_clicked()
{    delet *w = new delet(this); // Create a new login dialog instance
    w->setAttribute(Qt::WA_DeleteOnClose); // Ensure it gets deleted on close
    w->show();

}

