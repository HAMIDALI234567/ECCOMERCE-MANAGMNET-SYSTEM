#include "login.h"
#include "ui_login.h"
#include <QFile>
#include <QDataStream>
#include <QMessageBox>
#include<adminpanel.h>
#include<showdetails.h>
login::login(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::login)
{
    ui->setupUi(this);
}

login::~login()
{
    delete ui;
}

void login::on_pushButton_clicked()
{
    QString username = ui->lineEdit_username->text();
    QString password = ui->lineEdit_password->text();

    if (username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "Error", "Username or Password cannot be empty!");
        return;
    }

    QFile file("credential.dat");
    if (!file.open(QIODevice::ReadOnly)) {
        QMessageBox::critical(this, "Error", "Failed to open file for reading.");
        return;
    }

    QDataStream in(&file);
    QString storedUsername, storedPassword;
    bool found = false;

    while (!in.atEnd()) {
        in >> storedUsername >> storedPassword;
        if (storedUsername == username && storedPassword == password) {
            found = true;
            break;
        }
    }

    file.close();

    if (found) {
        QMessageBox::information(this, "Success", "Successfully signed in!");
    } else {
        QMessageBox::warning(this, "Error", "Invalid username or password!");
    }
    showdetails *w = new showdetails(this); // Create a new login dialog instance
    w->setAttribute(Qt::WA_DeleteOnClose); // Ensure it gets deleted on close
    w->show();
}


