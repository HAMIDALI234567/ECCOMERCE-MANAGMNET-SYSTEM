#include "delet.h"
#include "ui_delet.h"
#include <QMessageBox>
#include <QFile>
#include <QTextStream>

// Constructor
delet::delet(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::delet)
{
    ui->setupUi(this);

    // Placeholder Text
    ui->lineEdit->setPlaceholderText("Enter Unique Code");
}

// Destructor
delet::~delet()
{
    delete ui;
}

// Slot: on_pushButton_clicked
void delet::on_pushButton_clicked()
{
    QString code = ui->lineEdit->text();

    if (code.trimmed().isEmpty()) {
        QMessageBox::warning(this, "Input Error", "Unique Code field cannot be empty!");
        return;
    }

    QFile file("products.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "File Error", "Unable to open file for reading.");
        return;
    }

    QString updatedContent;
    QTextStream in(&file);
    bool codeFound = false;

    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList parts = line.split(",");
        if (parts.size() == 3 && parts[2].trimmed() == code) {
            codeFound = true;
            continue; // Skip this line (delete it)
        }
        updatedContent += line + "\n";
    }

    file.close();

    if (!codeFound) {
        QMessageBox::warning(this, "Not Found", "The entered code does not exist!");
        return;
    }

    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "File Error", "Unable to open file for writing.");
        return;
    }

    QTextStream out(&file);
    out << updatedContent;
    file.close();

    QMessageBox::information(this, "Success", "The product has been deleted successfully.");
    ui->lineEdit->clear();
}
