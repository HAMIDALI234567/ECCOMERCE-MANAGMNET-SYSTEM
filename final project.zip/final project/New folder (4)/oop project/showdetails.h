#ifndef SHOWDETAILS_H
#define SHOWDETAILS_H

#include <QDialog>
#include <QStandardItemModel>

namespace Ui {
class showdetails;
}

class showdetails : public QDialog
{
    Q_OBJECT

public:
    explicit showdetails(QWidget *parent = nullptr);
    ~showdetails();

private slots:
    void processBilling(); // Declare the billing method

private:
    Ui::showdetails *ui;
    QStandardItemModel *model; // Declare the model here
};

#endif // SHOWDETAILS_H
